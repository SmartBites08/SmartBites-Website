import estilos from './Botao.module.css'

interface BotaoProps {
    rotulo: string
    tipo?: 'primario' | 'secundario' | 'perigo'
    aoClicar?: () => void
    submit?: boolean
    icone?: React.ReactNode
}

export function Botao({ rotulo, tipo = 'primario', aoClicar, submit = false, icone }: BotaoProps) {
    return (
        <button
            className={`${estilos.botao} ${estilos[tipo]}`}
            type={submit ? 'submit' : 'button'}
            onClick={aoClicar}
        >
            {icone && <span className={estilos.icone}>{icone}</span>}
            {rotulo}
        </button>
    )
}
