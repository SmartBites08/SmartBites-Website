import estilos from './Receitas.module.css'
import { useContext, useState } from 'react'
import { Link } from 'react-router-dom'
import { FiPlus } from 'react-icons/fi'
import { ReceitasContexto } from '../contextos/ReceitasContexto'

export function Receitas() {

    const { receitasContexto } = useContext(ReceitasContexto)
    const [filtroAtivo, setFiltroAtivo] = useState('Todas')
    const filtros = ['Todas', 'Rápidas', 'Saudáveis', '+ Com IA']

    const receitasFiltradas = receitasContexto.filter(receita => {
        if (filtroAtivo === 'Todas') return true
        if (filtroAtivo === 'Rápidas') return parseInt(receita.tempoPreparo) <= 20
        if (filtroAtivo === 'Saudáveis') return receita.tags.includes('saudável')
        if (filtroAtivo === '+ Com IA') return receita.comIA
        return true
    })

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Receitas</h2>
            <div className={estilos.controles}>
                <h3 className={estilos.subtitulo}>Receitas disponíveis</h3>
                <div className={estilos.filtros}>
                    {filtros.map(f => (
                        <button
                            key={f}
                            className={`${estilos.filtro} ${filtroAtivo === f ? estilos.filtroAtivo : ''}`}
                            onClick={() => setFiltroAtivo(f)}
                        >{f}</button>
                    ))}
                    <Link to="/principal/receitas/nova" className={estilos.botaoAdicionar}>
                        <FiPlus size={16} /> Adicionar receita
                    </Link>
                </div>
            </div>
            <div className={estilos.grid}>
                {receitasFiltradas.map(receita => (
                    <Link key={receita.id} to={`/principal/receitas/${receita.id}`} className={estilos.card}>
                        <div className={`${estilos.cardImagem} ${receita.comIA ? estilos.cardImagemIA : ''}`}>
                            {receita.comIA && <span className={estilos.iaBadge}>+ IA</span>}
                            <span className={estilos.cardEmoji}>{receita.emoji}</span>
                        </div>
                        <div className={estilos.cardCorpo}>
                            <h4 className={estilos.cardTitulo}>{receita.titulo}</h4>
                            <div className={estilos.cardMeta}>
                                <span>⏱ {receita.tempoPreparo}</span>
                                <span>👤 {receita.porcoes} porção</span>
                            </div>
                            <div className={estilos.tags}>
                                {receita.tags.map(tag => (
                                    <span key={tag} className={`${estilos.tag} ${tag === 'saudável' ? estilos.tagSaudavel : ''}`}>
                                        {tag}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </Link>
                ))}
            </div>
        </main>
    )
}
