import estilos from './Cabecalho.module.css'
import { FiBell, FiPlus, FiSearch } from 'react-icons/fi'
import { useLocation } from 'react-router-dom'

export function Cabecalho() {

    const location = useLocation()
    const mostrarBusca = location.pathname === '/principal/despensa'

    return (
        <header className={estilos.conteiner}>
            {mostrarBusca && (
                <div className={estilos.busca}>
                    <FiSearch className={estilos.iconeBusca} />
                    <input
                        className={estilos.inputBusca}
                        placeholder="Buscar ingredientes..."
                    />
                </div>
            )}
            <div className={estilos.acoes}>
                <button className={estilos.botaoIcone}>
                    <FiBell size={20} />
                </button>
                <button className={estilos.botaoIcone}>
                    <FiPlus size={20} />
                </button>
            </div>
        </header>
    )
}
