import estilos from './Dashboard.module.css'
import { Alerta } from '../componentes/fundamentos/Alerta'
import { Card } from '../componentes/fundamentos/Card'
import { useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlimentosContexto } from '../contextos/AlimentosContexto'
import { ReceitasContexto } from '../contextos/ReceitasContexto'

function calcularDiasRestantes(dataValidade: string) {
    const hoje = new Date()
    hoje.setHours(0, 0, 0, 0)
    const validade = new Date(`${dataValidade}T00:00:00`)
    const diffMs = validade.getTime() - hoje.getTime()
    return Math.ceil(diffMs / (1000 * 60 * 60 * 24))
}

export function Dashboard() {

    const navegacao = useNavigate()
    const { alimentosContexto } = useContext(AlimentosContexto)
    const { receitasContexto } = useContext(ReceitasContexto)

    const alimentosComDias = alimentosContexto
        .map(item => ({ ...item, diasRestantes: calcularDiasRestantes(item.dataValidade) }))
        .sort((a, b) => a.diasRestantes - b.diasRestantes)

    const totalItens = alimentosComDias.length
    const vencidos = alimentosComDias.filter(item => item.diasRestantes < 0).length
    const vencendoEmBreve = alimentosComDias.filter(item => item.diasRestantes >= 0 && item.diasRestantes <= 5).length

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Visão Geral</h2>

            {vencendoEmBreve > 0 && (
                <Alerta
                    mensagem={`Atenção! Você tem ${vencendoEmBreve} ${vencendoEmBreve === 1 ? 'item vencendo' : 'itens vencendo'} nos próximos 5 dias. Use-os antes que estraguem!`}
                    tipo="aviso"
                    icone="⚠️"
                />
            )}

            <div className={estilos.cardsGrid}>
                <Card className={estilos.cardStat}>
                    <span className={estilos.cardEmoji}>🥦</span>
                    <p className={estilos.cardNumero}>{totalItens}</p>
                    <p className={estilos.cardRotulo}>Itens na despensa</p>
                </Card>
                <Card className={estilos.cardStat}>
                    <span className={estilos.cardEmoji}>⏱️</span>
                    <p className={estilos.cardNumero}>{vencendoEmBreve}</p>
                    <p className={estilos.cardRotulo}>Vencem em breve</p>
                    <span className={estilos.cardTag} style={{ color: 'var(--cor-alerta-aviso)' }}>próximos 5 dias</span>
                </Card>
                <Card className={estilos.cardStat}>
                    <span className={estilos.cardEmoji}>🚨</span>
                    <p className={estilos.cardNumero}>{vencidos}</p>
                    <p className={estilos.cardRotulo}>Já vencidos</p>
                    {vencidos > 0 && <span className={estilos.cardTag} style={{ color: 'var(--cor-alerta-perigo)' }}>retirar</span>}
                </Card>
                <Card className={estilos.cardStat}>
                    <span className={estilos.cardEmoji}>📋</span>
                    <p className={estilos.cardNumero}>{receitasContexto.length}</p>
                    <p className={estilos.cardRotulo}>Receitas cadastradas</p>
                </Card>
            </div>

            <div className={estilos.conteudoGrid}>
                <Card>
                    <div className={estilos.tabelaTopo}>
                        <h3 className={estilos.secaoTitulo}>Itens recentes</h3>
                        <div className={estilos.filtros}>
                            <button className={`${estilos.filtro} ${estilos.filtroAtivo}`}>Todos</button>
                            <button className={estilos.filtro} onClick={() => navegacao('/principal/despensa')}>Ver tudo →</button>
                        </div>
                    </div>
                    <div className={estilos.listaItens}>
                        {alimentosComDias.length === 0 && (
                            <p className={estilos.itemVazio}>Nenhum item cadastrado ainda. Adicione algo na sua despensa!</p>
                        )}
                        {alimentosComDias.slice(0, 5).map(item => (
                            <div key={item.id} className={estilos.itemLinha}>
                                <span className={estilos.itemEmoji}>{item.emoji}</span>
                                <div className={estilos.itemInfo}>
                                    <span className={estilos.itemNome}>{item.nome}</span>
                                    <span className={estilos.itemDetalhe}>{item.quantidade}{item.unidade} · 🧊 {item.local}</span>
                                </div>
                                <span className={estilos.itemDias}>
                                    {item.diasRestantes < 0 ? 'Vencido' : `${item.diasRestantes}d`}
                                </span>
                            </div>
                        ))}
                    </div>
                </Card>

                <Card className={estilos.cardIA}>
                    <div className={estilos.iaBadge}>+ IA Chef</div>
                    <h3 className={estilos.iaTitulo}>O que você quer cozinhar hoje?</h3>
                    <p className={estilos.iaSubtitulo}>Sugiro receitas com o que você tem em casa</p>
                   
                    <div className={estilos.iaFiltros}>
                        <button className={estilos.iaFiltro}>⚡ Rápida</button>
                        <button className={estilos.iaFiltro}>💪 Fitness</button>
                        <button className={estilos.iaFiltro}>🌿 Veggie</button>
                    </div>
                    <button className={estilos.iaBotao} onClick={() => navegacao('/principal/ia-chef')}>Ir para IA Chef</button>
                    <p className={estilos.iaExemploLabel}>Exemplo de sugestão:</p>
                    <p className={estilos.iaExemploTexto}>Com os seus ingredientes, sugiro:<br />
                        🌿 Omelete de vegetais — rápida, nutritiva (15 min)
                    </p>
                </Card>
            </div>
        </main>
    )
}
