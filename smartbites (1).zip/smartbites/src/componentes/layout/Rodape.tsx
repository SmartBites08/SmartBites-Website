import estilos from './Rodape.module.css'

export function Rodape() {
    return (
        <footer className={estilos.conteiner}>
            <p className={estilos.titulo}>Etec de Hortolândia — 3DS · SmartBites © 2026 </p> 
         
        </footer>
    )
}
