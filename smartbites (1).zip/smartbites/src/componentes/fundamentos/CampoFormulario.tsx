import estilos from './CampoFormulario.module.css'

interface CampoFormularioProps {
    rotulo: string
    tipo?: string
    placeholder?: string
    erro?: string
    registro: object
}

export function CampoFormulario({ rotulo, tipo = 'text', placeholder, erro, registro }: CampoFormularioProps) {
    return (
        <div className={estilos.conteiner}>
            <label className={estilos.rotulo}>{rotulo}</label>
            <input
                {...registro}
                className={`${estilos.campo} ${erro ? estilos.campoErro : ''}`}
                type={tipo}
                placeholder={placeholder}
            />
            {erro && <p className={estilos.mensagemErro}>{erro}</p>}
        </div>
    )
}
