import estilos from './Principal.module.css'
import { useContext } from 'react'
import { Cabecalho } from './Cabecalho'
import { Menu } from './Menu'
import { Rodape } from './Rodape'
import { Navigate, Outlet } from 'react-router-dom'
import { LayoutContexto } from '../../contextos/LayoutContexto'

export function Principal() {

    const { menuAbertoContexto, usuarioContexto, carregandoAuthContexto } = useContext(LayoutContexto)

    if (carregandoAuthContexto) {
        return null
    }

    if (!usuarioContexto) {
        return <Navigate to="/" replace />
    }

    return (
        <div
            className={estilos.gridConteiner}
            style={{ gridTemplateColumns: menuAbertoContexto ? '220px 1fr' : '68px 1fr' }}
        >
            <Menu />
            <Cabecalho />
            <Outlet />
            <Rodape />
        </div>
    )
}
