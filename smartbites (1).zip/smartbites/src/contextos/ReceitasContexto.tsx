import { createContext, useContext, useEffect, useState } from 'react'
import { type ReactNode } from 'react'
import { collection, addDoc, onSnapshot, query } from 'firebase/firestore'
import { db } from '../servicos/firebase'
import { LayoutContexto } from './LayoutContexto'
import { type ReceitaTipo } from '../tipos/Receita'

interface ReceitasProviderProps {
  children: ReactNode
}

export type NovaReceita = Omit<ReceitaTipo, 'id'>

interface ReceitasTipoContexto {
  receitasContexto: ReceitaTipo[]
  carregandoReceitasContexto: boolean
  adicionarReceitaContexto: (receita: NovaReceita) => Promise<void>
  buscarReceitaContexto: (id: string) => ReceitaTipo | undefined
}

export const ReceitasContexto = createContext<ReceitasTipoContexto>({
  receitasContexto: [],
  carregandoReceitasContexto: true,
  adicionarReceitaContexto: async () => {},
  buscarReceitaContexto: () => undefined
})

export const ReceitasProvider = ({ children }: ReceitasProviderProps) => {

  const { usuarioContexto } = useContext(LayoutContexto)
  const [receitasContexto, setReceitasContexto] = useState<ReceitaTipo[]>([])
  const [carregandoReceitasContexto, setCarregandoReceitasContexto] = useState(true)

  useEffect(() => {
    if (!usuarioContexto) {
      setReceitasContexto([])
      setCarregandoReceitasContexto(false)
      return
    }

    setCarregandoReceitasContexto(true)

    const colecao = collection(db, 'usuarios', usuarioContexto.uid, 'receitas')
    const cancelarInscricao = onSnapshot(query(colecao), snapshot => {
      const receitas = snapshot.docs.map(documento => ({
        id: documento.id,
        ...(documento.data() as Omit<ReceitaTipo, 'id'>)
      }))
      setReceitasContexto(receitas)
      setCarregandoReceitasContexto(false)
    })

    return () => cancelarInscricao()
  }, [usuarioContexto])

  const adicionarReceitaContexto = async (receita: NovaReceita) => {
    if (!usuarioContexto) return
    const colecao = collection(db, 'usuarios', usuarioContexto.uid, 'receitas')
    await addDoc(colecao, receita)
  }

  const buscarReceitaContexto = (id: string) => receitasContexto.find(item => item.id === id)

  return (
    <ReceitasContexto.Provider value={{
      receitasContexto,
      carregandoReceitasContexto,
      adicionarReceitaContexto,
      buscarReceitaContexto
    }}>
      {children}
    </ReceitasContexto.Provider>
  )
}
