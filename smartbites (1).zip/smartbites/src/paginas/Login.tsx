import estilos from './Login.module.css'
import { useContext, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { MdLogin } from 'react-icons/md'
import { FiUserPlus } from 'react-icons/fi'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { FirebaseError } from 'firebase/app'
import { auth } from '../servicos/firebase'
import { LayoutContexto } from '../contextos/LayoutContexto'
import bannerAutenticacao from '../assets/imagens/banner-autenticacao.jpg'

type FormValues = {
    email: string
    senha: string
}

const loginSchema = z.object({
    email: z.email({ message: 'Informe um e-mail válido.' }),
    senha: z.string().min(6, { message: 'Senha deve ter no mínimo 6 caracteres.' })
})

const mensagensErroFirebase: Record<string, string> = {
    'auth/invalid-credential': 'E-mail ou senha incorretos.',
    'auth/user-not-found': 'Não encontramos uma conta com esse e-mail.',
    'auth/wrong-password': 'E-mail ou senha incorretos.',
    'auth/too-many-requests': 'Muitas tentativas. Aguarde um momento e tente novamente.',
    'auth/network-request-failed': 'Falha de conexão. Verifique sua internet.'
}

export function Login() {

    const navegacao = useNavigate()
    const { usuarioContexto, carregandoAuthContexto } = useContext(LayoutContexto)
    const [erroAutenticacao, setErroAutenticacao] = useState('')
    const [enviando, setEnviando] = useState(false)

    const {
        register, handleSubmit, formState: { errors }
    } = useForm<FormValues>({ resolver: zodResolver(loginSchema) })

    useEffect(() => {
        if (!carregandoAuthContexto && usuarioContexto) {
            navegacao('/principal')
        }
    }, [carregandoAuthContexto, usuarioContexto, navegacao])

    const autenticarUsuario = async (data: FormValues) => {
        setErroAutenticacao('')
        setEnviando(true)
        try {
            await signInWithEmailAndPassword(auth, data.email, data.senha)
            navegacao('/principal')
        } catch (erro) {
            if (erro instanceof FirebaseError) {
                setErroAutenticacao(mensagensErroFirebase[erro.code] ?? 'Não foi possível entrar. Tente novamente.')
            } else {
                setErroAutenticacao('Não foi possível entrar. Tente novamente.')
            }
        } finally {
            setEnviando(false)
        }
    }

    return (
        <div className={estilos.conteiner}>

            <div className={estilos.painelEsquerdo}>
                <img
                    src={bannerAutenticacao}
                    alt="SmartBites — Gerencie sua despensa e descubra novas receitas"
                    className={estilos.brandingImagem}
                />
            </div>

            <div className={estilos.painelDireito}>
                <div className={estilos.formConteiner}>

                    <div className={estilos.cabecalho}>
                        <h2 className={estilos.titulo}>Bem-vindo de volta!</h2>
                        <p className={estilos.subTitulo}>Faça login para acessar sua despensa.</p>
                    </div>

                    <form
                        className={estilos.formulario}
                        onSubmit={handleSubmit(autenticarUsuario)}
                    >
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>E-mail</label>
                            <input
                                {...register('email')}
                                className={estilos.campo}
                                placeholder="seu@email.com"
                                type="email"
                            />
                            {errors.email && <p className={estilos.mensagemErro}>{errors.email.message}</p>}
                        </div>

                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Senha</label>
                            <input
                                {...register('senha')}
                                className={estilos.campo}
                                placeholder="••••••"
                                type="password"
                            />
                            {errors.senha && <p className={estilos.mensagemErro}>{errors.senha.message}</p>}
                        </div>

                        {erroAutenticacao && <p className={estilos.mensagemErro}>{erroAutenticacao}</p>}

                        <button className={estilos.botao} type="submit" disabled={enviando}>
                            <MdLogin size={18} />
                            {enviando ? 'Entrando...' : 'Entrar'}
                        </button>
                    </form>

                    <p className={estilos.linkCadastro}>
                        Não tem conta?{' '}
                        <Link className={estilos.link} to="/usuario">
                            <FiUserPlus size={14} />
                            Cadastre-se 
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    )
}
