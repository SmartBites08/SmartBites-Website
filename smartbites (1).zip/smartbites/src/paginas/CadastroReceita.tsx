import estilos from './CadastroAlimento.module.css'
import { useContext, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { ModalMensagem } from '../componentes/ModalMensagem'
import { FiSave } from 'react-icons/fi'
import { ReceitasContexto } from '../contextos/ReceitasContexto'

type FormValues = {
    titulo: string
    tempoPreparo: string
    porcoes: string
    emoji: string
    ingredientes: string
    modoPreparo: string
    tags: string
    comIA: boolean
}

const receitaSchema = z.object({
    titulo: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres.'),
    tempoPreparo: z.string().min(1, 'Informe o tempo de preparo.'),
    porcoes: z.string().min(1, 'Informe o número de porções.'),
    emoji: z.string().min(1, 'Escolha um emoji para a receita.'),
    ingredientes: z.string().min(1, 'Informe ao menos um ingrediente.'),
    modoPreparo: z.string().min(1, 'Descreva ao menos um passo do preparo.'),
    tags: z.string().optional(),
    comIA: z.boolean()
})

export function CadastroReceita() {

    const navigate = useNavigate()
    const { adicionarReceitaContexto } = useContext(ReceitasContexto)

    const [modalVisivel, setModalVisivel] = useState(false)
    const [modalTexto, setModalTexto] = useState('')
    const [enviando, setEnviando] = useState(false)
    const [erroSalvar, setErroSalvar] = useState('')

    const {
        register, handleSubmit, formState: { errors }, reset
    } = useForm<FormValues>({
        resolver: zodResolver(receitaSchema),
        defaultValues: { emoji: '🍽️', comIA: false }
    })

    const salvarReceita = async (data: FormValues) => {
        const ingredientes = data.ingredientes.split(',').map(i => i.trim()).filter(Boolean)
        const modoPreparo = data.modoPreparo.split('\n').map(p => p.trim()).filter(Boolean)
        const tags = (data.tags ?? '').split(',').map(t => t.trim()).filter(Boolean)

        setErroSalvar('')
        setEnviando(true)
        try {
            await adicionarReceitaContexto({
                titulo: data.titulo,
                tempoPreparo: data.tempoPreparo,
                porcoes: data.porcoes,
                emoji: data.emoji,
                ingredientes,
                modoPreparo,
                tags,
                comIA: data.comIA
            })

            setModalTexto(
                `Receita cadastrada com sucesso!\n\nTítulo: ${data.titulo}\nTempo de preparo: ${data.tempoPreparo}\nPorções: ${data.porcoes}`
            )
            setModalVisivel(true)
            reset({ emoji: '🍽️', comIA: false, titulo: '', tempoPreparo: '', porcoes: '', ingredientes: '', modoPreparo: '', tags: '' })
        } catch {
            setErroSalvar('Não foi possível salvar a receita. Tente novamente.')
        } finally {
            setEnviando(false)
        }
    }

    const ocultarModal = () => {
        setModalVisivel(false)
        navigate('/principal/receitas')
    }

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Cadastro de Receita</h2>

            <div className={estilos.formCard}>
                <form className={estilos.formulario} onSubmit={handleSubmit(salvarReceita)}>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Título da receita *</label>
                            <input {...register('titulo')} className={estilos.campo} placeholder="Ex: Risoto de brócolis" />
                            {errors.titulo && <p className={estilos.erro}>{errors.titulo.message}</p>}
                        </div>
                    </div>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Tempo de preparo *</label>
                            <input {...register('tempoPreparo')} className={estilos.campo} placeholder="Ex: 30 min" />
                            {errors.tempoPreparo && <p className={estilos.erro}>{errors.tempoPreparo.message}</p>}
                        </div>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Porções *</label>
                            <input {...register('porcoes')} className={estilos.campo} placeholder="Ex: 2" />
                            {errors.porcoes && <p className={estilos.erro}>{errors.porcoes.message}</p>}
                        </div>
                    </div>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Emoji *</label>
                            <input {...register('emoji')} className={estilos.campo} placeholder="Ex: 🍝" maxLength={4} />
                            {errors.emoji && <p className={estilos.erro}>{errors.emoji.message}</p>}
                        </div>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Tags (separadas por vírgula)</label>
                            <input {...register('tags')} className={estilos.campo} placeholder="Ex: saudável, rápida" />
                        </div>
                    </div>

                    <div className={estilos.campoGrupo}>
                        <label className={estilos.rotulo}>Ingredientes (separados por vírgula) *</label>
                        <input {...register('ingredientes')} className={estilos.campo} placeholder="Ex: arroz, brócolis, alho" />
                        {errors.ingredientes && <p className={estilos.erro}>{errors.ingredientes.message}</p>}
                    </div>

                    <div className={estilos.campoGrupo}>
                        <label className={estilos.rotulo}>Modo de preparo (um passo por linha) *</label>
                        <textarea
                            {...register('modoPreparo')}
                            className={estilos.campo}
                            rows={6}
                            placeholder={'Ex:\nRefogue o alho e a cebola.\nAdicione o arroz e mexa por 2 minutos.\n...'}
                        />
                        {errors.modoPreparo && <p className={estilos.erro}>{errors.modoPreparo.message}</p>}
                    </div>

                    <label className={estilos.checkboxGrupo}>
                        <input type="checkbox" {...register('comIA')} />
                        Marcar como sugestão gerada com IA
                    </label>

                    {erroSalvar && <p className={estilos.erro}>{erroSalvar}</p>}
                    <div className={estilos.acoes}>
                        <button type="submit" className={estilos.botaoSalvar} disabled={enviando}>
                            <FiSave size={16} /> {enviando ? 'Salvando...' : 'Salvar receita'}
                        </button>
                    </div>
                </form>
            </div>

            <ModalMensagem
                exibir={modalVisivel}
                ocultar={ocultarModal}
                titulo="Receita cadastrada"
                texto={modalTexto}
            />
        </main>
    )
}
