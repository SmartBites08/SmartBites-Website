import { type AlimentoTipo } from '../tipos/Alimento'
import { type ReceitaTipo } from '../tipos/Receita'

export const alimentosMock: AlimentoTipo[] = [
  { id: '1', nome: 'Brócolis', quantidade: '300', unidade: 'g', categoria: 'Vegetais', local: 'Geladeira', dataValidade: '2025-06-23', emoji: '🥦' },
  { id: '2', nome: 'Ovos', quantidade: '6', unidade: 'unid.', categoria: 'Proteínas', local: 'Geladeira', dataValidade: '2025-06-20', emoji: '🥚' },
  { id: '3', nome: 'Tomate cereja', quantidade: '200', unidade: 'g', categoria: 'Vegetais', local: 'Geladeira', dataValidade: '2025-06-17', emoji: '🍅' },
  { id: '4', nome: 'Arroz branco', quantidade: '1', unidade: 'kg', categoria: 'Grãos', local: 'Despensa', dataValidade: '2025-12-15', emoji: '🍚' },
  { id: '5', nome: 'Frango filé', quantidade: '500', unidade: 'g', categoria: 'Proteínas', local: 'Freezer', dataValidade: '2025-07-18', emoji: '🍗' },
  { id: '6', nome: 'Cebola', quantidade: '3', unidade: 'unid.', categoria: 'Vegetais', local: 'Despensa', dataValidade: '2025-07-08', emoji: '🧅' },
  { id: '7', nome: 'Alho', quantidade: '1', unidade: 'cabeça', categoria: 'Vegetais', local: 'Despensa', dataValidade: '2025-07-02', emoji: '🧄' },
  { id: '8', nome: 'Leite', quantidade: '1', unidade: 'L', categoria: 'Laticínios', local: 'Geladeira', dataValidade: '2025-06-21', emoji: '🥛' },
  { id: '9', nome: 'Cenoura', quantidade: '4', unidade: 'unid.', categoria: 'Vegetais', local: 'Geladeira', dataValidade: '2025-06-25', emoji: '🥕' },
  { id: '10', nome: 'Macarrão', quantidade: '500', unidade: 'g', categoria: 'Grãos', local: 'Despensa', dataValidade: '2025-10-15', emoji: '🍝' },
]

export const receitasMock: ReceitaTipo[] = [
  { id: '1', titulo: 'Risoto cremoso de brócolis', tempoPreparo: '35 min', porcoes: '2', ingredientes: ['brócolis', 'arroz'], modoPreparo: [
      'Separe os buquês de brócolis e reserve os talos picados.',
      'Refogue o alho e a cebola em azeite até dourar levemente.',
      'Acrescente o arroz e mexa por 2 minutos até ficar translúcido.',
      'Adicione caldo aos poucos, mexendo sempre, até o arroz cozinhar.',
      'Junte o brócolis nos últimos 5 minutos de cozimento.',
      'Finalize com queijo ralado e sirva quente.'
    ], tags: ['brócolis', 'arroz', 'saudável'], emoji: '🍲', comIA: false },
  { id: '2', titulo: 'Omelete de vegetais', tempoPreparo: '15 min', porcoes: '1', ingredientes: ['ovos', 'tomate'], modoPreparo: [
      'Bata os ovos em uma tigela com sal e pimenta a gosto.',
      'Pique o tomate e os demais vegetais em cubos pequenos.',
      'Aqueça uma frigideira antiaderente com um fio de azeite.',
      'Despeje os ovos batidos e espalhe os vegetais por cima.',
      'Cozinhe em fogo baixo até firmar e dobre ao meio para servir.'
    ], tags: ['ovos', 'tomate'], emoji: '🍳', comIA: true },
  { id: '3', titulo: 'Frango grelhado com legumes', tempoPreparo: '30 min', porcoes: '2', ingredientes: ['frango', 'cenoura'], modoPreparo: [
      'Tempere o filé de frango com sal, pimenta e limão.',
      'Corte a cenoura e demais legumes em rodelas ou tiras.',
      'Grelhe o frango em fogo médio por cerca de 6 minutos de cada lado.',
      'Em outra frigideira, salteie os legumes com um fio de azeite.',
      'Sirva o frango fatiado acompanhado dos legumes grelhados.'
    ], tags: ['frango', 'cenoura', 'saudável'], emoji: '🥗', comIA: false },
  { id: '4', titulo: 'Arroz com frango simples', tempoPreparo: '40 min', porcoes: '3', ingredientes: ['arroz', 'frango'], modoPreparo: [
      'Corte o frango em cubos e tempere com sal e alho.',
      'Doure o frango em uma panela com um fio de óleo.',
      'Adicione o arroz e refogue por 2 minutos junto com o frango.',
      'Cubra com água quente na proporção de 2 partes de água para 1 de arroz.',
      'Cozinhe em fogo baixo com a panela tampada até secar a água.',
      'Deixe descansar 5 minutos antes de servir.'
    ], tags: ['arroz', 'frango'], emoji: '🍱', comIA: false },
  { id: '5', titulo: 'Sopa de legumes', tempoPreparo: '45 min', porcoes: '4', ingredientes: ['cenoura', 'cebola'], modoPreparo: [
      'Pique a cebola, a cenoura e os demais legumes disponíveis.',
      'Refogue a cebola em azeite até ficar transparente.',
      'Adicione os legumes picados e refogue por mais 2 minutos.',
      'Cubra com água ou caldo de legumes e tempere a gosto.',
      'Cozinhe em fogo médio por cerca de 30 minutos até os legumes ficarem macios.',
      'Se preferir, bata parte da sopa no liquidificador para engrossar.'
    ], tags: ['cenoura', 'cebola', 'saudável'], emoji: '🍜', comIA: true },
  { id: '6', titulo: 'Macarrão ao alho e óleo', tempoPreparo: '20 min', porcoes: '2', ingredientes: ['macarrão', 'alho'], modoPreparo: [
      'Cozinhe o macarrão em água fervente com sal até ficar al dente.',
      'Fatie o alho em lâminas finas.',
      'Aqueça o azeite em fogo baixo e doure o alho sem queimar.',
      'Escorra o macarrão e misture direto na frigideira com o alho.',
      'Finalize com salsinha picada e sirva imediatamente.'
    ], tags: ['macarrão', 'alho'], emoji: '🍝', comIA: true },
]
