import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Login } from '../paginas/Login'
import { NovoUsuario } from '../paginas/NovoUsuario'
import { Principal } from '../componentes/layout/Principal'
import { Dashboard } from '../paginas/Dashboard'
import { MinhaDespensa } from '../paginas/MinhaDespensa'
import { CadastroAlimento } from '../paginas/CadastroAlimento'
import { Receitas } from '../paginas/Receitas'
import { CadastroReceita } from '../paginas/CadastroReceita'
import { DetalheReceita } from '../paginas/DetalheReceita'
import { IAChef } from '../paginas/IAChef'
import { Relatorios } from '../paginas/Relatorios'
import { Configuracoes } from '../paginas/Configuracoes'
import { Sobre } from '../paginas/Sobre'

export function Rotas() {
    return (
        <BrowserRouter>
            <Routes>

                <Route path='/' element={<Login />} />
                <Route path='/usuario' element={<NovoUsuario />} />

                <Route path='/principal' element={<Principal />}>
                    <Route index element={<Dashboard />} />
                    <Route path='despensa' element={<MinhaDespensa />} />
                    <Route path='cadastro-alimento' element={<CadastroAlimento />} />
                    <Route path='cadastro-alimento/:id' element={<CadastroAlimento />} />
                    <Route path='receitas' element={<Receitas />} />
                    <Route path='receitas/nova' element={<CadastroReceita />} />
                    <Route path='receitas/:id' element={<DetalheReceita />} />
                    <Route path='ia-chef' element={<IAChef />} />
                    <Route path='relatorios' element={<Relatorios />} />
                    <Route path='configuracoes' element={<Configuracoes />} />
                    <Route path='sobre' element={<Sobre />} />
                </Route>

            </Routes>
        </BrowserRouter>
    )
}
