import { createContext, useEffect, useState } from 'react'
import { type ReactNode } from 'react'
import { onAuthStateChanged, signOut, type User } from 'firebase/auth'
import { auth } from '../servicos/firebase'

interface LayoutProviderProps {
  children: ReactNode
}

interface LayoutTipoContexto {
  menuAbertoContexto: boolean
  usuarioContexto: User | null
  carregandoAuthContexto: boolean
  nomeUsuarioContexto: string
  emailUsuarioContexto: string
  setMenuAbertoContexto: (menu: boolean) => void
  logoutContexto: () => Promise<void>
}

export const LayoutContexto = createContext<LayoutTipoContexto>({
  menuAbertoContexto: true,
  usuarioContexto: null,
  carregandoAuthContexto: true,
  nomeUsuarioContexto: '',
  emailUsuarioContexto: '',
  setMenuAbertoContexto: () => {},
  logoutContexto: async () => {}
})

export const LayoutProvider = ({ children }: LayoutProviderProps) => {

  const [menuAbertoContexto, setMenuAbertoContexto] = useState(true)
  const [usuarioContexto, setUsuarioContexto] = useState<User | null>(null)
  const [carregandoAuthContexto, setCarregandoAuthContexto] = useState(true)

  useEffect(() => {
    // Escuta o estado de login do Firebase. Isso mantém o usuário
    // logado entre recarregamentos de página (sessão persistente).
    const cancelarInscricao = onAuthStateChanged(auth, usuario => {
      setUsuarioContexto(usuario)
      setCarregandoAuthContexto(false)
    })

    return () => cancelarInscricao()
  }, [])

  const logoutContexto = async () => {
    await signOut(auth)
  }

  return (
    <LayoutContexto.Provider value={{
      menuAbertoContexto,
      setMenuAbertoContexto,
      usuarioContexto,
      carregandoAuthContexto,
      nomeUsuarioContexto: usuarioContexto?.displayName ?? '',
      emailUsuarioContexto: usuarioContexto?.email ?? '',
      logoutContexto
    }}>
      {children}
    </LayoutContexto.Provider>
  )
}
