import estilos from './Menu.module.css'
import { useContext } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { LayoutContexto} from '../../contextos/LayoutContexto'
import { MdMenu, MdMenuOpen, MdDashboard, MdKitchen, MdMenuBook, MdAutoAwesome, MdBarChart, MdSettings, MdInfo, MdLogout } from 'react-icons/md'
import logo from '../../assets/imagens/logo.png'

export function Menu() {

    const location = useLocation()
    const navegacao = useNavigate()

    const { menuAbertoContexto, setMenuAbertoContexto, emailUsuarioContexto, logoutContexto } = useContext(LayoutContexto)

    const controlarMenu = () => setMenuAbertoContexto(!menuAbertoContexto)

    const sair = async () => {
        await logoutContexto()
        navegacao('/')
    }

    const iniciais = emailUsuarioContexto
        .split(' ')
        .slice(0, 2)
        .map(n => n[0])
        .join('')
        .toUpperCase()

    const itensMenu = [
        { rotulo: 'Visão Geral', caminho: '/principal', icone: <MdDashboard size={22} /> },
        { rotulo: 'Minha Despensa', caminho: '/principal/despensa', icone: <MdKitchen size={22} /> },
        { rotulo: 'Receitas', caminho: '/principal/receitas', icone: <MdMenuBook size={22} /> },
        { rotulo: 'IA Chef', caminho: '/principal/ia-chef', icone: <MdAutoAwesome size={22} /> },
        { rotulo: 'Relatórios', caminho: '/principal/relatorios', icone: <MdBarChart size={22} /> },
        { rotulo: 'Configurações', caminho: '/principal/configuracoes', icone: <MdSettings size={22} /> },
        { rotulo: 'Sobre', caminho: '/principal/sobre', icone: <MdInfo size={22} /> },
    ]

    return (
        <aside
            className={estilos.conteiner}
            style={{ width: menuAbertoContexto ? '220px' : '68px' }}
        >
            <div className={estilos.logo}>
                <img
                    src={logo}
                    alt="SmartBites"
                    className={estilos.logoImagem}
                />
                {menuAbertoContexto && <span className={estilos.logoTexto}>SmartBites</span>}
            </div>

            <button
                className={estilos.botaoMenu}
                onClick={controlarMenu}
            >
                {menuAbertoContexto ? <MdMenuOpen size={22} /> : <MdMenu size={22} />}
            </button>

            {menuAbertoContexto && <p className={estilos.secaoLabel}>PRINCIPAL</p>}

            <nav className={estilos.itemConteiner}>
                {itensMenu.slice(0, 4).map(item => (
                    <Link
                        key={item.caminho}
                        className={`${estilos.item} ${location.pathname === item.caminho ? estilos.itemAtivo : ''}`}
                        to={item.caminho}
                    >
                        {item.icone}
                        {menuAbertoContexto && <span className={estilos.rotulo}>{item.rotulo}</span>}
                        {item.rotulo === 'Minha Despensa' && menuAbertoContexto && (
                            <span className={estilos.badge}></span>
                        )}
                    </Link>
                ))}

                {menuAbertoContexto && <p className={estilos.secaoLabel}>ANÁLISE</p>}

                {itensMenu.slice(4).map(item => (
                    <Link
                        key={item.caminho}
                        className={`${estilos.item} ${location.pathname === item.caminho ? estilos.itemAtivo : ''}`}
                        to={item.caminho}
                    >
                        {item.icone}
                        {menuAbertoContexto && <span className={estilos.rotulo}>{item.rotulo}</span>}
                    </Link>
                ))}
            </nav>

            <div className={estilos.rodapeMenu}>
                <div className={estilos.avatar}>{iniciais}</div>
                {menuAbertoContexto && (
                    <div className={estilos.usuarioInfo}>
                        <span className={estilos.usuarioNome}>{emailUsuarioContexto}</span>
                      
                    </div>
                )}
                <button
                    className={estilos.botaoSair}
                    onClick={sair}
                    title="Sair"
                >
                    <MdLogout size={18} />
                </button>
            </div>
        </aside>
    )
}
