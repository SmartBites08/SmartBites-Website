import estilos from './Tabela.module.css'

interface TabelaColuna {
    chave: string
    titulo: string
}

interface TabelaProps {
    colunas: TabelaColuna[]
    dados: Record<string, string | number>[]
}

export function Tabela({ colunas, dados }: TabelaProps) {
    return (
        <div className={estilos.conteiner}>
            <table className={estilos.tabela}>
                <thead>
                    <tr>
                        {colunas.map(col => (
                            <th key={col.chave} className={estilos.cabecalho}>{col.titulo}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {dados.map((linha, i) => (
                        <tr key={i} className={estilos.linha}>
                            {colunas.map(col => (
                                <td key={col.chave} className={estilos.celula}>{linha[col.chave]}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
