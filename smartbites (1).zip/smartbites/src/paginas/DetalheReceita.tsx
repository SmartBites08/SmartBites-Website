import estilos from './DetalheReceita.module.css'
import { Link, useParams } from 'react-router-dom'
import { FiArrowLeft, FiClock, FiUsers } from 'react-icons/fi'
import { useContext } from 'react'
import { ReceitasContexto } from '../contextos/ReceitasContexto'

export function DetalheReceita() {

    const { id } = useParams()
    const { buscarReceitaContexto } = useContext(ReceitasContexto)
    const receita = buscarReceitaContexto(id ?? '')

    if (!receita) {
        return (
            <main className={estilos.conteiner}>
                <p className={estilos.naoEncontrada}>Receita não encontrada.</p>
                <Link to="/principal/receitas" className={estilos.voltar}>
                    <FiArrowLeft size={16} /> Voltar para receitas
                </Link>
            </main>
        )
    }

    return (
        <main className={estilos.conteiner}>
            <Link to="/principal/receitas" className={estilos.voltar}>
                <FiArrowLeft size={16} /> Voltar para receitas
            </Link>

            <div className={estilos.cabecalho}>
                <div className={`${estilos.imagem} ${receita.comIA ? estilos.imagemIA : ''}`}>
                    {receita.comIA && <span className={estilos.iaBadge}>+ IA</span>}
                    <span className={estilos.emoji}>{receita.emoji}</span>
                </div>

                <div className={estilos.info}>
                    <h2 className={estilos.titulo}>{receita.titulo}</h2>
                    <div className={estilos.meta}>
                        <span><FiClock size={14} /> {receita.tempoPreparo}</span>
                        <span><FiUsers size={14} /> {receita.porcoes} porção(ões)</span>
                    </div>
                    <div className={estilos.tags}>
                        {receita.tags.map(tag => (
                            <span key={tag} className={`${estilos.tag} ${tag === 'saudável' ? estilos.tagSaudavel : ''}`}>
                                {tag}
                            </span>
                        ))}
                    </div>
                </div>
            </div>

            <div className={estilos.conteudo}>
                <section className={estilos.secao}>
                    <h3 className={estilos.secaoTitulo}>Ingredientes</h3>
                    <ul className={estilos.listaIngredientes}>
                        {receita.ingredientes.map(ingrediente => (
                            <li key={ingrediente} className={estilos.ingrediente}>{ingrediente}</li>
                        ))}
                    </ul>
                </section>

                <section className={estilos.secao}>
                    <h3 className={estilos.secaoTitulo}>Modo de preparo</h3>
                    <ol className={estilos.listaPassos}>
                        {receita.modoPreparo.map((passo, indice) => (
                            <li key={indice} className={estilos.passo}>
                                <span className={estilos.passoNumero}>{indice + 1}</span>
                                <p className={estilos.passoTexto}>{passo}</p>
                            </li>
                        ))}
                    </ol>
                </section>
            </div>
        </main>
    )
}
