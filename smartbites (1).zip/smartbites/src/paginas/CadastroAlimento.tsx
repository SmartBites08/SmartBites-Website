import estilos from './CadastroAlimento.module.css'
import { useContext, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useNavigate, useParams } from 'react-router-dom'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { ModalMensagem } from '../componentes/ModalMensagem'
import { FiSave } from 'react-icons/fi'
import { AlimentosContexto } from '../contextos/AlimentosContexto'

type FormValues = {
    nome: string
    quantidade: string
    unidade: string
    categoria: string
    local: string
    dataValidade: string
}

const alimentoSchema = z.object({
    nome: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres.'),
    quantidade: z.string().min(1, 'Informe a quantidade.'),
    unidade: z.string().min(1, 'Selecione a unidade.'),
    categoria: z.string().min(1, 'Selecione a categoria.'),
    local: z.string().min(1, 'Selecione o local de armazenamento.'),
    dataValidade: z.string().min(1, 'Informe a data de validade.')
})

export function CadastroAlimento() {

    const { id } = useParams()
    const modoEdicao = Boolean(id)
    const navigate = useNavigate()

    const { adicionarAlimentoContexto, editarAlimentoContexto, buscarAlimentoContexto } = useContext(AlimentosContexto)

    const [modalVisivel, setModalVisivel] = useState(false)
    const [modalTexto, setModalTexto] = useState('')
    const [enviando, setEnviando] = useState(false)
    const [erroSalvar, setErroSalvar] = useState('')

    const {
        register, handleSubmit, formState: { errors }, reset
    } = useForm<FormValues>({ resolver: zodResolver(alimentoSchema) })

    useEffect(() => {
        if (modoEdicao && id) {
            const alimento = buscarAlimentoContexto(id)
            if (alimento) {
                reset({
                    nome: alimento.nome,
                    quantidade: alimento.quantidade,
                    unidade: alimento.unidade,
                    categoria: alimento.categoria,
                    local: alimento.local,
                    dataValidade: alimento.dataValidade
                })
            }
        }
        // Reexecuta quando os alimentos chegam do Firestore (a busca inicial é assíncrona).
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [modoEdicao, id, buscarAlimentoContexto])

    const salvarAlimento = async (data: FormValues) => {
        setErroSalvar('')
        setEnviando(true)
        try {
            if (modoEdicao && id) {
                await editarAlimentoContexto(id, data)
                setModalTexto(
                    `Alimento atualizado com sucesso!\n\nNome: ${data.nome}\nQuantidade: ${data.quantidade} ${data.unidade}\nCategoria: ${data.categoria}\nLocal: ${data.local}\nValidade: ${data.dataValidade}`
                )
            } else {
                await adicionarAlimentoContexto(data)
                setModalTexto(
                    `Alimento cadastrado com sucesso!\n\nNome: ${data.nome}\nQuantidade: ${data.quantidade} ${data.unidade}\nCategoria: ${data.categoria}\nLocal: ${data.local}\nValidade: ${data.dataValidade}`
                )
            }
            setModalVisivel(true)
            if (!modoEdicao) reset()
        } catch {
            setErroSalvar('Não foi possível salvar o alimento. Tente novamente.')
        } finally {
            setEnviando(false)
        }
    }

    const ocultarModal = () => {
        setModalVisivel(false)
        if (modoEdicao) navigate('/principal/despensa')
    }

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>{modoEdicao ? 'Editar Alimento' : 'Cadastro de Alimento'}</h2>

            <div className={estilos.formCard}>
                <form className={estilos.formulario} onSubmit={handleSubmit(salvarAlimento)}>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Nome do alimento *</label>
                            <input {...register('nome')} className={estilos.campo} placeholder="Ex: Tomate cereja" />
                            {errors.nome && <p className={estilos.erro}>{errors.nome.message}</p>}
                        </div>
                    </div>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Quantidade *</label>
                            <input {...register('quantidade')} className={estilos.campo} placeholder="Ex: 500" type="number" />
                            {errors.quantidade && <p className={estilos.erro}>{errors.quantidade.message}</p>}
                        </div>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Unidade *</label>
                            <select {...register('unidade')} className={estilos.campo}>
                                <option value="">Selecionar...</option>
                                <option value="g">Gramas (g)</option>
                                <option value="kg">Quilogramas (kg)</option>
                                <option value="ml">Mililitros (ml)</option>
                                <option value="L">Litros (L)</option>
                                <option value="unid.">Unidades</option>
                            </select>
                            {errors.unidade && <p className={estilos.erro}>{errors.unidade.message}</p>}
                        </div>
                    </div>

                    <div className={estilos.linha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Categoria *</label>
                            <select {...register('categoria')} className={estilos.campo}>
                                <option value="">Selecionar...</option>
                                <option value="Vegetais">Vegetais e Legumes</option>
                                <option value="Grãos">Grãos e Cereais</option>
                                <option value="Proteínas">Proteínas</option>
                                <option value="Laticínios">Laticínios</option>
                                <option value="Massas">Massas</option>
                                <option value="Temperos">Temperos</option>
                                <option value="Frutas">Frutas</option>
                                <option value="Doces e Açúcares">Doces e Açúcares</option>
                                <option value="Óleos e Gorduras">Óleos e Gorduras</option>
                                <option value="Outros">Outros</option>
                            </select>
                            {errors.categoria && <p className={estilos.erro}>{errors.categoria.message}</p>}
                        </div>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Local de armazenamento *</label>
                            <select {...register('local')} className={estilos.campo}>
                                <option value="">Selecionar...</option>
                                <option value="Geladeira">Geladeira</option>
                                <option value="Despensa">Despensa</option>
                                <option value="Freezer">Freezer</option>
                            </select>
                            {errors.local && <p className={estilos.erro}>{errors.local.message}</p>}
                        </div>
                    </div>

                    <div className={estilos.campoGrupo}>
                        <label className={estilos.rotulo}>Data de validade *</label>
                        <input {...register('dataValidade')} className={estilos.campo} type="date" />
                        {errors.dataValidade && <p className={estilos.erro}>{errors.dataValidade.message}</p>}
                    </div>

                    {erroSalvar && <p className={estilos.erro}>{erroSalvar}</p>}
                    <div className={estilos.acoes}>
                        <button type="submit" className={estilos.botaoSalvar} disabled={enviando}>
                            <FiSave size={16} /> {enviando ? 'Salvando...' : (modoEdicao ? 'Salvar alterações' : 'Salvar alimento')}
                        </button>
                    </div>
                </form>
            </div>

            <ModalMensagem
                exibir={modalVisivel}
                ocultar={ocultarModal}
                titulo={modoEdicao ? 'Alimento atualizado' : 'Alimento cadastrado'}
                texto={modalTexto}
            />
        </main>
    )
}
