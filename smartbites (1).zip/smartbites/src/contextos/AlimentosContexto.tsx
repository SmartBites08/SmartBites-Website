import { createContext, useContext, useEffect, useState } from 'react'
import { type ReactNode } from 'react'
import {
  collection, addDoc, updateDoc, doc, onSnapshot, query
} from 'firebase/firestore'
import { db } from '../servicos/firebase'
import { LayoutContexto } from './LayoutContexto'
import { type AlimentoTipo } from '../tipos/Alimento'

interface AlimentosProviderProps {
  children: ReactNode
}

export type NovoAlimento = Omit<AlimentoTipo, 'id' | 'emoji'>

interface AlimentosTipoContexto {
  alimentosContexto: AlimentoTipo[]
  carregandoAlimentosContexto: boolean
  adicionarAlimentoContexto: (alimento: NovoAlimento) => Promise<void>
  editarAlimentoContexto: (id: string, alimento: NovoAlimento) => Promise<void>
  buscarAlimentoContexto: (id: string) => AlimentoTipo | undefined
}

const emojisPorCategoria: Record<string, string> = {
  'Vegetais': '🥬',
  'Grãos': '🌾',
  'Proteínas': '🍗',
  'Laticínios': '🧀',
  'Massas': '🍝',
  'Temperos': '🧂',
  'Frutas': '🍎',
  'Doces e Açúcares': '🍬',
  'Óleos e Gorduras': '🫒',
  'Outros': '🍽️'
}

export const AlimentosContexto = createContext<AlimentosTipoContexto>({
  alimentosContexto: [],
  carregandoAlimentosContexto: true,
  adicionarAlimentoContexto: async () => {},
  editarAlimentoContexto: async () => {},
  buscarAlimentoContexto: () => undefined
})

export const AlimentosProvider = ({ children }: AlimentosProviderProps) => {

  const { usuarioContexto } = useContext(LayoutContexto)
  const [alimentosContexto, setAlimentosContexto] = useState<AlimentoTipo[]>([])
  const [carregandoAlimentosContexto, setCarregandoAlimentosContexto] = useState(true)

  useEffect(() => {
    if (!usuarioContexto) {
      setAlimentosContexto([])
      setCarregandoAlimentosContexto(false)
      return
    }

    setCarregandoAlimentosContexto(true)

    const colecao = collection(db, 'usuarios', usuarioContexto.uid, 'alimentos')
    const cancelarInscricao = onSnapshot(query(colecao), snapshot => {
      const alimentos = snapshot.docs.map(documento => ({
        id: documento.id,
        ...(documento.data() as Omit<AlimentoTipo, 'id'>)
      }))
      setAlimentosContexto(alimentos)
      setCarregandoAlimentosContexto(false)
    })

    return () => cancelarInscricao()
  }, [usuarioContexto])

  const adicionarAlimentoContexto = async (alimento: NovoAlimento) => {
    if (!usuarioContexto) return
    const colecao = collection(db, 'usuarios', usuarioContexto.uid, 'alimentos')
    await addDoc(colecao, {
      ...alimento,
      emoji: emojisPorCategoria[alimento.categoria] ?? '🍽️'
    })
  }

  const editarAlimentoContexto = async (id: string, alimento: NovoAlimento) => {
    if (!usuarioContexto) return
    const referencia = doc(db, 'usuarios', usuarioContexto.uid, 'alimentos', id)
    await updateDoc(referencia, {
      ...alimento,
      emoji: emojisPorCategoria[alimento.categoria] ?? '🍽️'
    })
  }

  const buscarAlimentoContexto = (id: string) => alimentosContexto.find(item => item.id === id)

  return (
    <AlimentosContexto.Provider value={{
      alimentosContexto,
      carregandoAlimentosContexto,
      adicionarAlimentoContexto,
      editarAlimentoContexto,
      buscarAlimentoContexto
    }}>
      {children}
    </AlimentosContexto.Provider>
  )
}
