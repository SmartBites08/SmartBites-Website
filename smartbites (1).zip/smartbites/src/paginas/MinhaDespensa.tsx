import estilos from './MinhaDespensa.module.css'
import { Link } from 'react-router-dom'
import { FiPlus, FiEdit2 } from 'react-icons/fi'
import { useContext, useState } from 'react'
import { AlimentosContexto } from '../contextos/AlimentosContexto'

function calcularDiasRestantes(dataValidade: string) {
    const hoje = new Date()
    hoje.setHours(0, 0, 0, 0)
    const validade = new Date(`${dataValidade}T00:00:00`)
    const diffMs = validade.getTime() - hoje.getTime()
    return Math.ceil(diffMs / (1000 * 60 * 60 * 24))
}

export function MinhaDespensa() {

    const { alimentosContexto } = useContext(AlimentosContexto)
    const [filtroAtivo, setFiltroAtivo] = useState('Todos')
    const filtros = ['Todos', 'Geladeira', 'Despensa', 'Freezer', 'Vencendo']

    const alimentosFiltrados = filtroAtivo === 'Todos'
        ? alimentosContexto
        : alimentosContexto.filter(a => (
            filtroAtivo === 'Vencendo'
                ? calcularDiasRestantes(a.dataValidade) <= 5
                : a.local === filtroAtivo
        ))

    return (
        <main className={estilos.conteiner}>
            <div className={estilos.topBar}>
                <h2 className={estilos.titulo}>Minha Despensa</h2>
            </div>

            <div className={estilos.controles}>
                <h3 className={estilos.subtitulo}>Todos os itens</h3>
                <div className={estilos.filtros}>
                    {filtros.map(f => (
                        <button
                            key={f}
                            className={`${estilos.filtro} ${filtroAtivo === f ? estilos.filtroAtivo : ''}`}
                            onClick={() => setFiltroAtivo(f)}
                        >{f}</button>
                    ))}
                    <Link to="/principal/cadastro-alimento" className={estilos.botaoAdicionar}>
                        <FiPlus size={16} /> Adicionar item
                    </Link>
                </div>
            </div>

            <div className={estilos.grid}>
                {alimentosFiltrados.map(item => {
                    const diasRestantes = calcularDiasRestantes(item.dataValidade)
                    const vencido = diasRestantes < 0

                    return (
                        <Link
                            key={item.id}
                            to={`/principal/cadastro-alimento/${item.id}`}
                            className={estilos.card}
                        >
                            <div className={estilos.cardTopo}>
                                <span className={estilos.cardEmoji}>{item.emoji}</span>
                                <span className={`${estilos.cardDias} ${vencido ? estilos.vencido : ''}`}>
                                    {vencido ? 'Vencido' : `${diasRestantes}d`}
                                </span>
                            </div>
                            <p className={estilos.cardNome}>{item.nome}</p>
                            <p className={estilos.cardDetalhe}>{item.quantidade}{item.unidade} · 🧊 {item.local}</p>
                            <span className={estilos.editarLink}>
                                <FiEdit2 size={12} /> Editar
                            </span>
                            <div className={`${estilos.barra} ${vencido ? estilos.barraPerigo : estilos.barraNormal}`} />
                        </Link>
                    )
                })}
            </div>
        </main>
    )
}
