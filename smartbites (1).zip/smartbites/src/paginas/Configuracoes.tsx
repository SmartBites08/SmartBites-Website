import estilos from './Configuracoes.module.css'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { ModalMensagem } from '../componentes/ModalMensagem'



type FormValues = {
    nome: string
    email: string
}

const configSchema = z.object({
    nome: z.string().min(2, 'Mínimo de 2 caracteres.'),
    email: z.email({ message: 'Informe um e-mail válido.' })
})

export function Configuracoes() {

    const [alertaValidade, setAlertaValidade] = useState(true)
    const [sugestoesIA, setSugestoesIA] = useState(true)
    const [modalVisivel, setModalVisivel] = useState(false)
    const [modalTexto, setModalTexto] = useState('')

    const {
        register, handleSubmit, formState: { errors }
    } = useForm<FormValues>({
        resolver: zodResolver(configSchema),
        
    })

    const salvarAlteracoes = (data: FormValues) => {
        setModalTexto(
            `Configurações salvas!\n\nNome: ${data.nome}\nE-mail: ${data.email}\nAlerta de validade: ${alertaValidade ? 'Ativado' : 'Desativado'}\nSugestões da IA: ${sugestoesIA ? 'Ativado' : 'Desativado'}`
        )
        setModalVisivel(true)
    }

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Configurações</h2>

            <form className={estilos.formulario} onSubmit={handleSubmit(salvarAlteracoes)}>

                <div className={estilos.card}>
                    <h3 className={estilos.cardTitulo}>Perfil</h3>
                    <div className={estilos.perfilTopo}>
                        <div className={estilos.avatar}>MG</div>
                        <div>
                            <p className={estilos.avatarNome}>nome</p>
                            <p className={estilos.avatarEmail}>email@gmail.com</p>
                        </div>
                    </div>
                    <div className={estilos.camposLinha}>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Nome completo</label>
                            <input {...register('nome')} className={estilos.campo} />
                            {errors.nome && <p className={estilos.erro}>{errors.nome.message}</p>}
                        </div>
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>E-mail</label>
                            <input {...register('email')} className={estilos.campo} type="email" />
                            {errors.email && <p className={estilos.erro}>{errors.email.message}</p>}
                        </div>
                    </div>
                </div>

                <div className={estilos.card}>
                    <h3 className={estilos.cardTitulo}>Notificações</h3>
                    <div className={estilos.toggle}>
                        <div>
                            <p className={estilos.toggleTitulo}>Alerta de validade</p>
                            <p className={estilos.toggleSubtitulo}>Avise 3 dias antes do vencimento</p>
                        </div>
                        <button
                            type="button"
                            className={`${estilos.toggleBotao} ${alertaValidade ? estilos.toggleAtivo : ''}`}
                            onClick={() => setAlertaValidade(!alertaValidade)}
                        >
                            <span className={estilos.toggleCirculo} />
                        </button>
                    </div>
                    <div className={estilos.toggle}>
                        <div>
                            <p className={estilos.toggleTitulo}>Sugestões da IA</p>
                            <p className={estilos.toggleSubtitulo}>Receba receitas personalizadas</p>
                        </div>
                        <button
                            type="button"
                            className={`${estilos.toggleBotao} ${sugestoesIA ? estilos.toggleAtivo : ''}`}
                            onClick={() => setSugestoesIA(!sugestoesIA)}
                        >
                            <span className={estilos.toggleCirculo} />
                        </button>
                    </div>
                </div>

                <div className={estilos.acoes}>
                    <button type="submit" className={estilos.botaoSalvar}>Salvar alterações</button>
                    <button type="button" className={estilos.botaoCancelar}>Cancelar</button>
                </div>
            </form>

            <ModalMensagem
                exibir={modalVisivel}
                ocultar={() => setModalVisivel(false)}
                titulo="Configurações salvas"
                texto={modalTexto}
            />
        </main>
    )
}
