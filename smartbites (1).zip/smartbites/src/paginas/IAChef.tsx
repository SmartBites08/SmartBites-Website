import estilos from './IAChef.module.css'
import { useState } from 'react'

const sugestoesRapidas = ['⚡ Use o que vai vencer', '🥗 Almoço saudável', '🌿 Vegetariana', '🍮 Sobremesa', '☕ Café da manhã']

export function IAChef() {
    const [prompt, setPrompt] = useState('')
    const [gerado, setGerado] = useState(false)

    const gerarReceitas = () => {
        if (prompt.trim()) setGerado(true)
    }

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>IA Chef</h2>
            <div className={estilos.centrado}>
                <h1 className={estilos.paginaTitulo}>IA Chef SmartBites</h1>
                <p className={estilos.paginaSubtitulo}>Receitas personalizadas com base nos ingredientes da sua despensa</p>

                <div className={estilos.card}>
                   
                    <h3 className={estilos.cardTitulo}>O que você tem em mente?</h3>
                    <p className={estilos.cardSubtitulo}>Descreva o que você quer ou deixe eu sugerir com o que você tem</p>

                    <textarea
                        className={estilos.textarea}
                        placeholder="Ex: quero uma refeição completa para 2 pessoas, prefiro algo leve, tenho frango e legumes..."
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                    />

                    <p className={estilos.sugestoesLabel}>SUGESTÕES RÁPIDAS</p>
                    <div className={estilos.sugestoes}>
                        {sugestoesRapidas.map(s => (
                            <button key={s} className={estilos.sugestao} onClick={() => setPrompt(s)}>
                                {s}
                            </button>
                        ))}
                    </div>

                    <div className={estilos.cardRodape}>
                        <p className={estilos.autoEnvio}>Seus ingredientes são enviados automaticamente</p>
                        <button className={estilos.botaoGerar} onClick={gerarReceitas}>
                            + Gerar receitas
                        </button>
                    </div>

                    <div className={estilos.exemplo}>
                        <p className={estilos.exemploLabel}>
                            {gerado ? 'Sugestão gerada:' : 'Exemplo de sugestão:'}
                        </p>
                        <p className={estilos.exemploTexto}>Com os seus ingredientes, sugiro:</p>
                        <ul className={estilos.exemploLista}>
                            <li>🌿 Omelete de vegetais — rápida, nutritiva, usa seus ovos antes de vencerem (15 min)</li>
                            <li>🥦 Refogado de brócolis com alho — leve e saboroso (20 min)</li>
                            <li>🍗 Arroz de forno com frango — prático para toda família (40 min)</li>
                        </ul>
                        <p className={estilos.aviso}>Área reservada para integração com API.</p>
                    </div>
                </div>
            </div>
        </main>
    )
}
