import estilos from './Alerta.module.css'

interface AlertaProps {
    mensagem: string
    tipo?: 'aviso' | 'perigo' | 'sucesso' | 'info'
    icone?: string
}

export function Alerta({ mensagem, tipo = 'aviso', icone = '⚠️' }: AlertaProps) {
    return (
        <div className={`${estilos.conteiner} ${estilos[tipo]}`}>
            <span>{icone}</span>
            <p className={estilos.mensagem}>{mensagem}</p>
        </div>
    )
}
