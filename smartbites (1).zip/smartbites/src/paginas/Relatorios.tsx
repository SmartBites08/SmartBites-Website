import estilos from './Relatorios.module.css'
import { Card } from '../componentes/fundamentos/Card'
import { useContext } from 'react'
import { AlimentosContexto } from '../contextos/AlimentosContexto'

function calcularDiasRestantes(dataValidade: string) {
    const hoje = new Date()
    hoje.setHours(0, 0, 0, 0)
    const validade = new Date(`${dataValidade}T00:00:00`)
    const diffMs = validade.getTime() - hoje.getTime()
    return Math.ceil(diffMs / (1000 * 60 * 60 * 24))
}

const coresPorCategoria: Record<string, string> = {
    'Vegetais': '#2D5016',
    'Grãos': '#E8991C',
    'Proteínas': '#C0442C',
    'Laticínios': '#4A90D9',
    'Massas': '#D4A373',
    'Temperos': '#8B5E3C',
    'Frutas': '#E63946',
    'Doces e Açúcares': '#F4A6C6',
    'Óleos e Gorduras': '#B08968',
    'Outros': '#D4E8C0'
}

export function Relatorios() {

    const { alimentosContexto } = useContext(AlimentosContexto)

    const alimentosComDias = alimentosContexto.map(item => ({
        ...item,
        diasRestantes: calcularDiasRestantes(item.dataValidade)
    }))

    const totalItens = alimentosComDias.length
    const vencidos = alimentosComDias.filter(item => item.diasRestantes < 0).length
    const vencendoEmBreve = alimentosComDias.filter(item => item.diasRestantes >= 0 && item.diasRestantes <= 5).length
    const itensEmDia = totalItens - vencidos - vencendoEmBreve

    const statsCards = [
        { emoji: '📦', valor: String(totalItens), rotulo: 'Itens na despensa', cor: 'var(--cor-primaria-clara)' },
        { emoji: '⏳', valor: String(vencendoEmBreve), rotulo: 'Vencendo em breve', cor: 'var(--cor-alerta-aviso)' },
        { emoji: '⚠️', valor: String(vencidos), rotulo: 'Itens vencidos', cor: 'var(--cor-alerta-perigo)' },
        { emoji: '✅', valor: String(itensEmDia), rotulo: 'Itens em dia', cor: 'var(--cor-alerta-sucesso)' },
    ]

    const categoriasContagem = alimentosContexto.reduce<Record<string, number>>((acc, item) => {
        acc[item.categoria] = (acc[item.categoria] ?? 0) + 1
        return acc
    }, {})

    const categoriasOrdenadas = Object.entries(categoriasContagem).sort((a, b) => b[1] - a[1])

    let acumulado = 0
    const fatiasDonut = categoriasOrdenadas.map(([categoria, qtd]) => {
        const inicio = acumulado
        const fim = acumulado + (totalItens > 0 ? (qtd / totalItens) * 100 : 0)
        acumulado = fim
        return { categoria, qtd, cor: coresPorCategoria[categoria] ?? '#9CA3AF', inicio, fim }
    })

    const gradiente = fatiasDonut.length > 0
        ? `conic-gradient(${fatiasDonut.map(f => `${f.cor} ${f.inicio}% ${f.fim}%`).join(', ')})`
        : '#E5E5E5'

    const itensProximosVencimento = [...alimentosComDias]
        .sort((a, b) => a.diasRestantes - b.diasRestantes)
        .slice(0, 6)

    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Relatórios</h2>

            <div className={estilos.statsGrid}>
                {statsCards.map(s => (
                    <Card key={s.rotulo} className={estilos.statCard}>
                        <div className={estilos.statIcone} style={{ borderTop: `4px solid ${s.cor}` }}>
                            <span>{s.emoji}</span>
                        </div>
                        <p className={estilos.statValor}>{s.valor}</p>
                        <p className={estilos.statRotulo}>{s.rotulo}</p>
                    </Card>
                ))}
            </div>

            <div className={estilos.graficosGrid}>
                <Card>
                    <h3 className={estilos.secaoTitulo}>Distribuição por categoria</h3>
                    <div className={estilos.donut}>
                        <div className={estilos.donutCirculo} style={{ background: gradiente }}>
                            <span className={estilos.donutNumero}>{totalItens}</span>
                            <span className={estilos.donutLabel}>itens total</span>
                        </div>
                    </div>
                    <div className={estilos.legenda}>
                        {fatiasDonut.length === 0 && (
                            <p className={estilos.vazio}>Nenhum item cadastrado na despensa ainda.</p>
                        )}
                        {fatiasDonut.map(f => (
                            <div key={f.categoria} className={estilos.legendaItem}>
                                <span className={estilos.legendaDot} style={{ backgroundColor: f.cor }} />
                                <span className={estilos.legendaTexto}>{f.categoria}</span>
                                <span className={estilos.legendaQtd}>{f.qtd}</span>
                            </div>
                        ))}
                    </div>
                </Card>

                <Card>
                    <h3 className={estilos.secaoTitulo}>Itens próximos do vencimento</h3>
                    <div className={estilos.barras}>
                        {itensProximosVencimento.length === 0 && (
                            <p className={estilos.vazio}>Nenhum item cadastrado na despensa ainda.</p>
                        )}
                        {itensProximosVencimento.map(item => {
                            const vencido = item.diasRestantes < 0
                            const pct = vencido
                                ? 100
                                : Math.max(0, Math.min(100, 100 - (item.diasRestantes / 15) * 100))
                            const cor = vencido
                                ? 'var(--cor-alerta-perigo)'
                                : item.diasRestantes <= 5
                                    ? 'var(--cor-alerta-aviso)'
                                    : 'var(--cor-primaria-clara)'

                            return (
                                <div key={item.id} className={estilos.barraItem}>
                                    <span className={estilos.barraNome}>{item.emoji} {item.nome}</span>
                                    <div className={estilos.barraTrilha}>
                                        <div
                                            className={estilos.barraPreenchimento}
                                            style={{ width: `${pct}%`, backgroundColor: cor }}
                                        />
                                    </div>
                                    <span className={estilos.barraUso}>
                                        {vencido ? 'Vencido' : `${item.diasRestantes}d`}
                                    </span>
                                </div>
                            )
                        })}
                    </div>
                </Card>
            </div>
        </main>
    )
}
