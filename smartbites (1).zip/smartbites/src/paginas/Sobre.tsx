import estilos from './Sobre.module.css'

const integrantes = [
    { nome: 'Gabriela da Silva Moura',   },
    { nome: 'João Pedro Felipe da Silva', },
    { nome: ' Mateus Facchini' },
]

const tecnologias = [
    { nome: 'React 19', descricao: 'Biblioteca para construção de interfaces', emoji: '⚛️' },
    { nome: 'TypeScript', descricao: 'Tipagem estática para JavaScript', emoji: '📘' },
    { nome: 'Vite', descricao: 'Build tool moderna e ultrarrápida', emoji: '⚡' },
    { nome: 'React Router Dom', descricao: 'Roteamento entre páginas', emoji: '🗺️' },
    { nome: 'React Hook Form', descricao: 'Gerenciamento de formulários', emoji: '📝' },
    { nome: 'Zod', descricao: 'Validação de esquemas com TypeScript', emoji: '🛡️' },
    { nome: 'CSS Modules', descricao: 'Estilização modular por componente', emoji: '🎨' },
    { nome: 'React Icons', descricao: 'Biblioteca de ícones SVG', emoji: '🔷' },
]

export function Sobre() {
    return (
        <main className={estilos.conteiner}>
            <h2 className={estilos.titulo}>Sobre</h2>

            {/* Resumo do projeto */}
            <section className={estilos.card}>
                <div className={estilos.projectHeader}>
                    <span className={estilos.projectEmoji}>🥗</span>
                    <div>
                        <h3 className={estilos.projectNome}>SmartBites</h3>
                        <span className={estilos.projectTag}>Sistema de Gerenciamento de Estoque Doméstico</span>
                    </div>
                </div>
                <p className={estilos.projectDescricao}>
                    O SmartBites é um sistema web desenvolvido para auxiliar no gerenciamento de estoque doméstico
                    de alimentos, com funcionalidades de sugestão de receitas baseadas nos ingredientes disponíveis.
                    O sistema permite o controle de validade dos produtos, reduzindo o desperdício alimentar e
                    promovendo um consumo mais inteligente e sustentável.
                </p>
            </section>

            {/* Objetivos */}
            <section className={estilos.card}>
                <h3 className={estilos.secaoTitulo}>Objetivos do Sistema</h3>
                <ul className={estilos.objetivos}>
                    <li className={estilos.objetivo}>
                        <span className={estilos.objetivoEmoji}>📦</span>
                        <div>
                            <p className={estilos.objetivoTitulo}>Controle de Estoque</p>
                            <p className={estilos.objetivoDesc}>Gerenciar os alimentos presentes na despensa, geladeira e freezer com informações de quantidade e validade.</p>
                        </div>
                    </li>
                    <li className={estilos.objetivo}>
                        <span className={estilos.objetivoEmoji}>⚠️</span>
                        <div>
                            <p className={estilos.objetivoTitulo}>Alertas de Validade</p>
                            <p className={estilos.objetivoDesc}>Notificar o usuário sobre alimentos próximos do vencimento, evitando desperdício.</p>
                        </div>
                    </li>
                    <li className={estilos.objetivo}>
                        <span className={estilos.objetivoEmoji}>🍳</span>
                        <div>
                            <p className={estilos.objetivoTitulo}>Sugestão de Receitas</p>
                            <p className={estilos.objetivoDesc}>Sugerir receitas com base nos ingredientes disponíveis, priorizando itens próximos do vencimento.</p>
                        </div>
                    </li>
                    <li className={estilos.objetivo}>
                        <span className={estilos.objetivoEmoji}>🤖</span>
                        <div>
                            <p className={estilos.objetivoTitulo}>IA Chef</p>
                            <p className={estilos.objetivoDesc}>Utilizar inteligência artificial para personalizar receitas de acordo com as preferências do usuário.</p>
                        </div>
                    </li>
                    <li className={estilos.objetivo}>
                        <span className={estilos.objetivoEmoji}>📊</span>
                        <div>
                            <p className={estilos.objetivoTitulo}>Relatórios</p>
                            <p className={estilos.objetivoDesc}>Gerar análises sobre o consumo, economia gerada e taxa de aproveitamento dos alimentos.</p>
                        </div>
                    </li>
                </ul>
            </section>

            {/* Integrantes */}
            <section className={estilos.card}>
                <h3 className={estilos.secaoTitulo}>Integrantes do Grupo</h3>
                <p className={estilos.secaoSubtitulo}>Turma 3DSB — Etec de Hortolândia · 2026</p>
                <div className={estilos.integrantesGrid}>
                    {integrantes.map((integrante, idx) => (
                        <div key={idx} className={estilos.integranteCard}>
                            {/* ↓ Substituir o src abaixo pela foto real de cada integrante */}
                            {/* Exemplo: import foto1 from '../assets/imagens/foto1.jpg' e usar src={foto1} */}
                            <div className={estilos.integranteFoto}>
                                <span className={estilos.integranteFotoIcone}>📷</span>
                                <p className={estilos.integranteFotoTexto}>Adicionar foto</p>
                            </div>
                            <p className={estilos.integranteNome}>{integrante.nome}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Tecnologias */}
            <section className={estilos.card}>
                <h3 className={estilos.secaoTitulo}>Tecnologias Utilizadas</h3>
                <div className={estilos.techGrid}>
                    {tecnologias.map(t => (
                        <div key={t.nome} className={estilos.techCard}>
                            <span className={estilos.techEmoji}>{t.emoji}</span>
                            <p className={estilos.techNome}>{t.nome}</p>
                            <p className={estilos.techDesc}>{t.descricao}</p>
                        </div>
                    ))}
                </div>
            </section>
        </main>
    )
}
