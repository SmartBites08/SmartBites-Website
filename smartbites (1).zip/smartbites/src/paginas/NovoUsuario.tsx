import estilos from './NovoUsuario.module.css'
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { FiUserPlus, FiArrowLeft } from 'react-icons/fi'
import { ModalMensagem } from '../componentes/ModalMensagem'
import { createUserWithEmailAndPassword, updateProfile, signOut } from 'firebase/auth'
import { FirebaseError } from 'firebase/app'
import { doc, setDoc, writeBatch, collection } from 'firebase/firestore'
import { auth, db } from '../servicos/firebase'
import { alimentosMock, receitasMock } from '../servicos/dadosMock'
import bannerAutenticacao from '../assets/imagens/banner-autenticacao.jpg'

type FormValues = {
    nome: string
    email: string
    senha: string
}

const cadastroSchema = z.object({
    nome: z.string()
          .min(2, 'Mínimo de 2 caracteres.')
          .max(50, 'Máximo de 50 caracteres.'),
    email: z.email({ message: 'Informe um e-mail válido.' }),
    senha: z.string().min(6, { message: 'Senha deve ter no mínimo 6 caracteres.' })
})

const mensagensErroFirebase: Record<string, string> = {
    'auth/email-already-in-use': 'Já existe uma conta com esse e-mail.',
    'auth/weak-password': 'Senha muito fraca. Use pelo menos 6 caracteres.',
    'auth/network-request-failed': 'Falha de conexão. Verifique sua internet.'
}

// Popula a conta recém-criada com os itens de exemplo, para o usuário
// já ter o que explorar no primeiro acesso (igual à versão de demonstração).
async function semearDadosIniciais(uid: string) {
    const lote = writeBatch(db)

    alimentosMock.forEach(alimento => {
        const { id: _id, ...dadosAlimento } = alimento
        const referencia = doc(collection(db, 'usuarios', uid, 'alimentos'))
        lote.set(referencia, dadosAlimento)
    })

    receitasMock.forEach(receita => {
        const { id: _id, ...dadosReceita } = receita
        const referencia = doc(collection(db, 'usuarios', uid, 'receitas'))
        lote.set(referencia, dadosReceita)
    })

    await lote.commit()
}

export function NovoUsuario() {

    const [modalMensagemVisivel, setModalMensagemVisivel] = useState(false)
    const [modalMensagemTitulo, setModalMensagemTitulo] = useState('')
    const [modalMensagemTexto, setModalMensagemTexto] = useState('')
    const [erroCadastro, setErroCadastro] = useState('')
    const [enviando, setEnviando] = useState(false)

    const {
        register, handleSubmit, formState: { errors }
    } = useForm<FormValues>({ resolver: zodResolver(cadastroSchema) })

    const navegacao = useNavigate()

    const adicionarUsuario = async (data: FormValues) => {
        setErroCadastro('')
        setEnviando(true)
        try {
            const credencial = await createUserWithEmailAndPassword(auth, data.email, data.senha)
            await updateProfile(credencial.user, { displayName: data.nome })
            await setDoc(doc(db, 'usuarios', credencial.user.uid), {
                nome: data.nome,
                email: data.email
            })
            await semearDadosIniciais(credencial.user.uid)

            // Volta para deslogado: o usuário confirma no modal e faz login normalmente.
            await signOut(auth)

            setModalMensagemTitulo('Cadastro realizado!')
            setModalMensagemTexto(
                `Bem-vindo ao SmartBites, ${data.nome}!\n\nNome: ${data.nome}\nE-mail: ${data.email}\n\nConta criada com sucesso! Faça login para continuar.`
            )
            setModalMensagemVisivel(true)
        } catch (erro) {
            if (erro instanceof FirebaseError) {
                setErroCadastro(mensagensErroFirebase[erro.code] ?? 'Não foi possível criar a conta. Tente novamente.')
            } else {
                setErroCadastro('Não foi possível criar a conta. Tente novamente.')
            }
        } finally {
            setEnviando(false)
        }
    }

    const ocultarModal = () => {
        setModalMensagemVisivel(false)
        navegacao('/')
    }

    return (
        <div className={estilos.conteiner}>

            <div className={estilos.painelEsquerdo}>
                <img
                    src={bannerAutenticacao}
                    alt="SmartBites — Gerencie sua despensa e descubra novas receitas"
                    className={estilos.brandingImagem}
                />
            </div>

            <div className={estilos.painelDireito}>
                <div className={estilos.formConteiner}>

                    <div className={estilos.cabecalho}>
                        <h2 className={estilos.titulo}>Criar conta</h2>
                        <p className={estilos.subTitulo}>Preencha os dados abaixo para se cadastrar</p>
                    </div>

                    <form
                        className={estilos.formulario}
                        onSubmit={handleSubmit(adicionarUsuario)}
                    >
                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Nome completo</label>
                            <input
                                {...register('nome')}
                                className={estilos.campo}
                                placeholder="Seu nome completo"
                            />
                            {errors.nome && <p className={estilos.mensagemErro}>{errors.nome.message}</p>}
                        </div>

                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>E-mail</label>
                            <input
                                {...register('email')}
                                className={estilos.campo}
                                placeholder="seu@email.com"
                                type="email"
                            />
                            {errors.email && <p className={estilos.mensagemErro}>{errors.email.message}</p>}
                        </div>

                        <div className={estilos.campoGrupo}>
                            <label className={estilos.rotulo}>Senha</label>
                            <input
                                {...register('senha')}
                                className={estilos.campo}
                                placeholder="Mínimo 6 caracteres"
                                type="password"
                            />
                            {errors.senha && <p className={estilos.mensagemErro}>{errors.senha.message}</p>}
                        </div>

                        {erroCadastro && <p className={estilos.mensagemErro}>{erroCadastro}</p>}

                        <button className={estilos.botao} type="submit" disabled={enviando}>
                            <FiUserPlus size={18} />
                            {enviando ? 'Criando conta...' : 'Cadastrar'}
                        </button>
                    </form>

                    <p className={estilos.linkVoltar}>
                        <Link className={estilos.link} to="/">
                            <FiArrowLeft size={14} />
                            Voltar ao login
                        </Link>
                    </p>
                </div>
            </div>

            <ModalMensagem
                exibir={modalMensagemVisivel}
                ocultar={ocultarModal}
                titulo={modalMensagemTitulo}
                texto={modalMensagemTexto}
            />
        </div>
    )
}
