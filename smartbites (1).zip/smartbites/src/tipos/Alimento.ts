export type AlimentoTipo = {
    id: string
    nome: string
    quantidade: string
    unidade: string
    categoria: string
    local: string
    dataValidade: string
    emoji: string
}
