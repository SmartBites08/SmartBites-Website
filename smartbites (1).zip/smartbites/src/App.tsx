import { Rotas } from './rotas/Rotas'
import { LayoutProvider } from './contextos/LayoutContexto'
import { AlimentosProvider } from './contextos/AlimentosContexto'
import { ReceitasProvider } from './contextos/ReceitasContexto'

function App() {
  return (
    <LayoutProvider>
      <AlimentosProvider>
        <ReceitasProvider>
          <Rotas />
        </ReceitasProvider>
      </AlimentosProvider>
    </LayoutProvider>
  )
}

export default App
