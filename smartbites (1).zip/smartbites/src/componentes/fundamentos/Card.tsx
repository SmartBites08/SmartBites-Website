import estilos from './Card.module.css'
import { type ReactNode } from 'react'

interface CardProps {
    children: ReactNode
    className?: string
}

export function Card({ children, className }: CardProps) {
    return (
        <div className={`${estilos.conteiner} ${className ?? ''}`}>
            {children}
        </div>
    )
}
