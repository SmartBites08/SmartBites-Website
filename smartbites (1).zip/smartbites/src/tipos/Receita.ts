export type ReceitaTipo = {
    id: string
    titulo: string
    tempoPreparo: string
    porcoes: string
    ingredientes: string[]
    modoPreparo: string[]
    tags: string[]
    emoji: string
    comIA: boolean
}
